from apireplacement import apireplacement

x = apireplacement.APIReplace('code.py')
x.find('code.py')
