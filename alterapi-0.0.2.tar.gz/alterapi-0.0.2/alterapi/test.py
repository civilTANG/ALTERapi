import alterapi
x = alterapi.APIReplace('code.py')
x.recommend()

